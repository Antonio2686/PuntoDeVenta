/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package puntodeventa;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author Antonio
 */
public class Conexion {
    
     String driver = "com.mysql.cj.jdbc.Driver";
     String prefijoConexion = "jdbc:mysql://";
     String ip = "127.0.0.1";//"172.16.0.217"; // Dirección IP donde está corriendo el SGBD
     String usr = ""; // Usuario
     String psw = ""; // Password
     String bd = "pdv";
    
    
        
        
    
    
    public static Connection getConexion(){
    
        Connection conexion = null;
        
        try{
            
            Class.forName("com.mysql.cj.jdbc.Driver" );
        conexion = DriverManager.getConnection("jdbc:mysql://127.0.0.1/pdv", "", "");
        }
        catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex.toString());
        }
    
    
    return conexion;
    }
    
    
    
    
    
}
